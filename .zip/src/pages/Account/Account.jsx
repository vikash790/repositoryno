export default function Account() {
  return (
    <>
   <h1 style={{ padding: "40px" }}>Welcome to Your Account</h1>
      <h2>hellowe</h2>
      </>
   ) ;
}
