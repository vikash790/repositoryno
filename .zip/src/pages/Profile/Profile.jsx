export default function Profile() {
  const user = {
    name: "Vikash Mishra",
    accountNumber: "1234 5678 9012",
    branch: "Patna Main Branch",
    contact: "+91 9876543210",
    email: "vikash@example.com"
  };

  return (
    <div className="profile-wrapper">
      <div className="profile-card">
        
        <h2 className="profile-title">Customer Profile</h2>

        <div className="profile-info">

          <div className="profile-row">
            <span className="label">Full Name:</span>
            <span className="value">{user.name}</span>
          </div>

          <div className="profile-row">
            <span className="label">Account Number:</span>
            <span className="value">{user.accountNumber}</span>
          </div>

          <div className="profile-row">
            <span className="label">Branch:</span>
            <span className="value">{user.branch}</span>
          </div>

          <div className="profile-row">
            <span className="label">Contact Number:</span>
            <span className="value">{user.contact}</span>
          </div>

          <div className="profile-row">
            <span className="label">Email:</span>
            <span className="value">{user.email}</span>
          </div>

        </div>

      </div>
    </div>
  );
}
