import Container from "../components/Container";

export default function UtilityBar() {
  return (
    <div className="utility-bar">
      <Container>
        <div className="utility-bar__inner">
          <div className="left">
            <a>Locations & ATMs</a>
            <a>Contact Us</a>
            <a>Open Account</a>
          </div>

          <div className="right">
            {/* <a>Type to Search…</a> */}
            <input type="text" placeholder="Type to Search…" />
          </div>
        </div>
      </Container>
    </div>
  );
}
