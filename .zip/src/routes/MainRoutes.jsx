// // import { Routes, Route } from "react-router-dom";
// // import PublicRoutes from "./PublicRoutes";
// // import ProtectedRoutes from "./ProtectedRoutes";

// // import RootLayout from "../layout/RootLayout";

// // import Home from "../pages/Home/Home";
// // import Loans from "../pages/Loans/Loans";
// // import Account from "../pages/Account/Account";
// // import NotFound from "../pages/NotFound";

// // export default function MainRoutes() {
// //   return (
// //     <Routes>
// //       <Route element={<RootLayout />}>
// //         {/* PUBLIC ROUTES */}
// //         <Route element={<PublicRoutes />}>
// //           <Route path="/" element={<Home />} />
// //           <Route path="/loans" element={<Loans />} />
// //         </Route>

// //         {/* PROTECTED ROUTES */}
// //         <Route element={<ProtectedRoutes />}>
// //           <Route path="/account" element={<Account />} />
// //         </Route>
// //       </Route>

// //       {/* 404 PAGE */}
// //       <Route path="*" element={<NotFound />} />
// //     </Routes>
// //   );
// // }


// import { Routes, Route } from "react-router-dom";

// import PublicRoutes from "./PublicRoutes";
// import ProtectedRoutes from "./ProtectedRoutes";

// import RootLayout from "../layout/RootLayout";

// import Home from "../pages/Home/Home";
// import Loans from "../pages/Loans/Loans";
// import Account from "../pages/Account/Account";
// import Login from "../pages/Auth/Login";
// import Register from "../pages/Auth/Register";
// import Otp from "../pages/Auth/Otp";

// import NotFound from "../pages/NotFound";


// export default function MainRoutes() {
//   return (
//     <Routes>
//       <Route element={<RootLayout />}>

//         {/* PUBLIC ROUTES */}
//         <Route element={<PublicRoutes />}>
//           <Route path="/" element={<Home />} />
//           <Route path="/loans" element={<Loans />} />

//           <Route path="/login" element={<Login />} />
//           <Route path="/register" element={<Register />} />
//         </Route>

        

//         {/* PROTECTED ROUTES */}
//         <Route element={<ProtectedRoutes />}>
//           <Route path="/account" element={<Account />} />
//         </Route>

//       </Route>

//       {/* 404 PAGE */}
//       <Route path="*" element={<NotFound />} />
//     </Routes>
//   );
// }


// import { Routes, Route } from "react-router-dom";

// import PublicRoutes from "./PublicRoutes";
// import ProtectedRoutes from "./ProtectedRoutes";

// import RootLayout from "../layout/RootLayout";

// import Home from "../pages/Home/Home";
// import Loans from "../pages/Loans/Loans";
// import Account from "../pages/Account/Account";
// import Login from "../pages/Auth/Login";
// import Register from "../pages/Auth/Register";
// import Otp from "../pages/Auth/Otp";

// import NotFound from "../pages/NotFound";
// import Profile from "../pages/Profile/Profile";
// import BulkPayment from "../pages/BulkPayment/BulkPayment";


// export default function MainRoutes() {
//   return (
//     <Routes>
//       <Route element={<RootLayout />}>

//         {/* PUBLIC ROUTES */}
//         <Route element={<PublicRoutes />}>
//           <Route path="/" element={<Home />} />
//           <Route path="/loans" element={<Loans />} />

//           <Route path="/login" element={<Login />} />
//           <Route path="/register" element={<Register />} />

//           {/*  Otp */}
//           <Route path="/otp" element={<Otp />} />
//         </Route>
//         <Route path="/profile" element={<Profile />} />
//         <Route path="/bulk-payment" element={<BulkPayment />} />

//         {/* PROTECTED ROUTES */}
//         <Route element={<ProtectedRoutes />}>
//           <Route path="/account" element={<Account />} />
//         </Route>

//       </Route>

//       {/* 404 PAGE */}
//       <Route path="*" element={<NotFound />} />
//     </Routes>
//   );
// }




// import { Routes, Route } from "react-router-dom";

// import PublicRoutes from "./PublicRoutes";
// import ProtectedRoutes from "./ProtectedRoutes";

// import RootLayout from "../layout/RootLayout";

// import Home from "../pages/Home/Home";
// import Loans from "../pages/Loans/Loans";
// import Account from "../pages/Account/Account";
// import Login from "../pages/Auth/Login";
// import Register from "../pages/Auth/Register";
// import Otp from "../pages/Auth/Otp";

// import NotFound from "../pages/NotFound";
// import Profile from "../pages/Profile/Profile";
// import BulkPayment from "../pages/BulkPayment/BulkPayment";

// export default function MainRoutes() {
//   return (
//     <Routes>
//       <Route element={<RootLayout />}>

//         {/* ------------------- PUBLIC ROUTES ------------------- */}
//         <Route element={<PublicRoutes />}>
//           <Route path="/" element={<Home />} />
//           <Route path="/loans" element={<Loans />} />
//           <Route path="/login" element={<Login />} />
//           <Route path="/register" element={<Register />} />
//           <Route path="/otp" element={<Otp />} />
//         </Route>
//         <Route path="/profile" element={<Profile />} />
//          <Route path="/bulkpayment" element={<Profile />} />
        
//         {/* ------------------- PROTECTED ROUTES ------------------- */}
//         <Route element={<ProtectedRoutes />}>
//           <Route path="/account" element={<Account />} />
//           <Route path="/profile" element={<Profile />} />
//           <Route path="/bulk-payment" element={<BulkPayment />} />
//         </Route>

//       </Route>

//       {/* ------------------- 404 PAGE ------------------- */}
//       <Route path="*" element={<NotFound />} />
//     </Routes>
//   );
// }


// import { Routes, Route } from "react-router-dom";

// import PublicRoutes from "./PublicRoutes";
// import ProtectedRoutes from "./ProtectedRoutes";

// import RootLayout from "../layout/RootLayout";

// import Home from "../pages/Home/Home";
// import Loans from "../pages/Loans/Loans";
// import Account from "../pages/Account/Account";
// import Login from "../pages/Auth/Login";
// import Register from "../pages/Auth/Register";
// import Otp from "../pages/Auth/Otp";

// import NotFound from "../pages/NotFound";
// import Profile from "../pages/Profile/Profile";
// import BulkPayment from "../pages/BulkPayment/BulkPayment";

// export default function MainRoutes() {
//   return (
//     <Routes>

//       <Route element={<RootLayout />}>

//         {/* PUBLIC ROUTES */}
//         <Route element={<PublicRoutes />}>
//           <Route path="/" element={<Home />} />
//           <Route path="/loans" element={<Loans />} />
//           <Route path="/login" element={<Login />} />
//           <Route path="/register" element={<Register />} />
//           <Route path="/otp" element={<Otp />} />
//         </Route>

//         {/* PROTECTED ROUTES */}
//         <Route element={<ProtectedRoutes />}>
//           <Route path="/account" element={<Account />} />
//           <Route path="/profile" element={<Profile />} />
//           <Route path="/bulk-payment" element={<BulkPayment />} />
//         </Route>

//       </Route>

//       {/* 404 */}
//       <Route path="*" element={<NotFound />} />

//     </Routes>
//   );
// }



// import { Routes, Route } from "react-router-dom";

// import PublicRoutes from "./PublicRoutes";
// import ProtectedRoutes from "./ProtectedRoutes";

// import RootLayout from "../layout/RootLayout";

// import Home from "../pages/Home/Home";
// import Loans from "../pages/Loans/Loans";
// import Account from "../pages/Account/Account";
// import Login from "../pages/Auth/Login";
// import Register from "../pages/Auth/Register";
// import Otp from "../pages/Auth/Otp";
// import ChangePassword from "../pages/Auth/ChangePassword";

// import NotFound from "../pages/NotFound";
// import Profile from "../pages/Profile/Profile";
// import BulkPayment from "../pages/BulkPayment/BulkPayment";

// export default function MainRoutes() {
//   return (
//     <Routes>

//       <Route element={<RootLayout />}>

//         {/* ---------------- PUBLIC ROUTES ---------------- */}
//         <Route element={<PublicRoutes />}>
//           <Route path="/" element={<Home />} />
//           <Route path="/loans" element={<Loans />} />
//           <Route path="/login" element={<Login />} />
//           <Route path="/register" element={<Register />} />
//           <Route path="/otp" element={<Otp />} />
//         </Route>

//         {/* ---------------- PROTECTED ROUTES ---------------- */}
//         <Route element={<ProtectedRoutes />}>
//           <Route path="/change-password" element={<ChangePassword />} />
//           <Route path="/account" element={<Account />} />
//           <Route path="/profile" element={<Profile />} />
//           <Route path="/bulk-payment" element={<BulkPayment />} />
//         </Route>

//       </Route>

//       {/* ---------------- 404 ---------------- */}
//       <Route path="*" element={<NotFound />} />

//     </Routes>
//   );
// }



// import { Routes, Route } from "react-router-dom";

// import PublicRoutes from "./PublicRoutes";
// import ProtectedRoutes from "./ProtectedRoutes";

// import RootLayout from "../layout/RootLayout";

// import Home from "../pages/Home/Home";
// import Loans from "../pages/Loans/Loans";
// import Account from "../pages/Account/Account";
// import Login from "../pages/Auth/Login";
// import Register from "../pages/Auth/Register";
// import Otp from "../pages/Auth/Otp";
// import ChangePassword from "../pages/Auth/ChangePassword";
// import CaptchaVerify from "../pages/Auth/CaptchaVerify";

// import NotFound from "../pages/NotFound";
// import Profile from "../pages/Profile/Profile";
// import BulkPayment from "../pages/BulkPayment/BulkPayment";

// export default function MainRoutes() {
//   return (
//     <Routes>

//       <Route element={<RootLayout />}>
//         {/* PUBLIC ROUTES */}
//         <Route element={<PublicRoutes />}>
//           <Route path="/" element={<Home />} />
//           <Route path="/loans" element={<Loans />} />
//           <Route path="/login" element={<Login />} />
//           <Route path="/register" element={<Register />} />
//           <Route path="/otp" element={<Otp />} />
//         </Route>

//         {/* PROTECTED ROUTES */}
//         <Route element={<ProtectedRoutes />}>
//           <Route path="/change-password" element={<ChangePassword />} />
//           <Route path="/verify-captcha" element={<CaptchaVerify />} />
//           <Route path="/account" element={<Account />} />
//           <Route path="/profile" element={<Profile />} />
//           <Route path="/bulk-payment" element={<BulkPayment />} />
//         </Route>
//       </Route>

//       {/* 404 */}
//       <Route path="*" element={<NotFound />} />

//     </Routes>
//   );
// }



import { Routes, Route } from "react-router-dom";

import PublicRoutes from "./PublicRoutes";
import ProtectedRoutes from "./ProtectedRoutes";

import RootLayout from "../layout/RootLayout";

import Home from "../pages/Home/Home";
import Loans from "../pages/Loans/Loans";
import Account from "../pages/Account/Account";
import Login from "../pages/Auth/Login";
import Register from "../pages/Auth/Register";
import Otp from "../pages/Auth/Otp";
import ChangePassword from "../pages/Auth/ChangePassword";
import CaptchaVerify from "../pages/Auth/CaptchaVerify";
import SecurityQuestion from "../pages/Auth/SecurityQuestion";

import NotFound from "../pages/NotFound";
import Profile from "../pages/Profile/Profile";
import BulkPayment from "../pages/BulkPayment/BulkPayment";

export default function MainRoutes() {
  return (
    <Routes>

      <Route element={<RootLayout />}>

        {/* PUBLIC ROUTES */}
        <Route element={<PublicRoutes />}>
          <Route path="/" element={<Home />} />
          <Route path="/loans" element={<Loans />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/otp" element={<Otp />} />
        </Route>

        {/* PROTECTED ROUTES */}
        <Route element={<ProtectedRoutes />}>
          <Route path="/change-password" element={<ChangePassword />} />
          <Route path="/verify-captcha" element={<CaptchaVerify />} />
          <Route path="/security-question" element={<SecurityQuestion />} />
          <Route path="/account" element={<Account />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/bulk-payment" element={<BulkPayment />} />
        </Route>

      </Route>

      {/* 404 */}
      <Route path="*" element={<NotFound />} />

    </Routes>
  );
}
