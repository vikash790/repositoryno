// // import { useNavigate } from "react-router-dom";
// // import { useAuth } from "../../context/AuthContext";

// // export default function Login() {
// //   const { login } = useAuth();
// //   const navigate = useNavigate();

// //   const handleLogin = (e) => {
// //     e.preventDefault();

// //     login(); // update login state
// //     navigate("/dashboard");
// //   };

// //   return (
// //     <div style={{ padding: "20px" }}>
// //       <h2>Login</h2>

// //       <form onSubmit={handleLogin}>
// //         <input type="email" placeholder="Email" required /><br /><br />
// //         <input type="password" placeholder="Password" required /><br /><br />

// //         <button type="submit">Login</button>
// //       </form>
// //     </div>
// //   );
// // }


// import { useNavigate } from "react-router-dom";
// import { useAuth } from "../../context/AuthContext";

// export default function Login() {
//   const { login } = useAuth();
//   const navigate = useNavigate();

//   const handleLogin = (e) => {
//     e.preventDefault();
//     login();
//     //  navigate("/change-password");
//     navigate("/verify-captcha");

//   };

//   return (
//     <div className="login-wrapper">
//       <div className="login-card">
//         <h2>Welcome Back</h2>
//         <p className="login-sub">Securely access your account</p>

//         <form onSubmit={handleLogin} className="login-form">
//           <div className="input-group">
//             <label>Email Address</label>
//             <input type="email" placeholder="example@bank.com" required />
//           </div>

//           <div className="input-group">
//             <label>Password</label>
//             <input type="password" placeholder="Enter your password" required />
//           </div>

//           <button type="submit" className="btn-primary big login-btn">
//             Login
//           </button>
//         </form>

//         <p className="signup-text">
//           Don’t have an account? <a href="/register">Register</a>
//         </p>
//       </div>
//     </div>
//   );
// }






// import { useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useAuth } from "../../context/AuthContext";
// import "./Auth.css";

// export default function Login() {
//   const { login } = useAuth();
//   const navigate = useNavigate();

//   const [showPassword, setShowPassword] = useState(false);

//   const handleLogin = (e) => {
//     e.preventDefault();
//     login();
//     navigate("/verify-captcha");
//   };

//   return (
//     <div className="login-wrapper">
//       <div className="login-card">
//         <h2>Welcome Back</h2>
//         <p className="login-sub">Securely access your account</p>

//         <form onSubmit={handleLogin} className="login-form">

//           <div className="input-group">
//             <label>Email Address</label>
//             <input
//               type="email"
//               placeholder="example@bank.com"
//               required
//             />
//           </div>

//           {/* PASSWORD WITH EYE ICON */}
//           <div className="input-group password-group">
//             <label>Password</label>
//             <input
//               type={showPassword ? "text" : "password"}
//               placeholder="Enter your password"
//               required
//             />
//             <span
//               className="eye-icon"
//               onClick={() => setShowPassword(!showPassword)}
//             >
//               {showPassword ? "🙈" : "👁️"}
//             </span>
//           </div>

//           <button type="submit" className="btn-primary big login-btn">
//             Login
//           </button>
//         </form>

//         <p className="signup-text">
//           Don’t have an account? <a href="/register">Register</a>
//         </p>
//       </div>
//     </div>
//   );
// }




// import { useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { useAuth } from "../../context/AuthContext";
// import "./Auth.css";

// export default function Login() {
//   const { login } = useAuth();
//   const navigate = useNavigate();

//   const [showPassword, setShowPassword] = useState(false);

//   const handleLogin = (e) => {
//     e.preventDefault();
//     login();
//     navigate("/verify-captcha");
//   };

//   return (
//     <div className="login-wrapper">
//       <div className="login-card">
//         <h2>Welcome Back</h2>
//         <p className="login-sub">Securely access your account</p>

//         <form onSubmit={handleLogin} className="login-form">

//           <div className="input-group">
//             <label>Email Address</label>
//             <input
//               type="email"
//               placeholder="example@bank.com"
//               required
//             />
//           </div>

//           {/* PASSWORD WITH EYE ICON */}
//           <div className="input-group password-group">
//             <label>Password</label>
//             <input
//               type={showPassword ? "text" : "password"}
//               placeholder="Enter your password"
//               required
//             />
//             <span
//               className="eye-icon"
//               onClick={() => setShowPassword(!showPassword)}
//             >
//               {showPassword ? "🙈" : "👁️"}
//             </span>
//           </div>

//           {/* FORGOT PASSWORD */}
//           <div className="forgot-password">
//             <button
//               type="button"
//               onClick={() => navigate("/forgot-password")}
//             >
//               Forgot Password?
//             </button>
//           </div>

//           <button type="submit" className="btn-primary big login-btn">
//             Login
//           </button>
//         </form>

//         <p className="signup-text">
//           Don’t have an account? <a href="/register">Register</a>
//         </p>
//       </div>
//     </div>
//   );
// }


import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import "./Auth.css";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = (e) => {
    e.preventDefault();
    login();
    navigate("/verify-captcha");
  };

  return (
    <div className="login-wrapper">
      <div className="login-card">
        <h2>Welcome Back</h2>
        <p className="login-sub">Securely access your account</p>

        <form onSubmit={handleLogin} className="login-form">

          {/* EMAIL */}
          <div className="input-group">
            <label>Email Address</label>
            <input
              type="email"
              placeholder="example@bank.com"
              required
            />
          </div>

          {/* PASSWORD */}
          <div className="input-group password-group">
            <label>Password</label>
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Enter your password"
              required
            />
            <span
              className="eye-icon"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? "🙈" : "👁️"}
            </span>
          </div>

          {/* FORGOT PASSWORD (CLEAN BANKING STYLE) */}
          <div className="login-actions">
            <span
              className="forgot-link"
              onClick={() => navigate("/forgot-password")}
            >
              Forgot password?
            </span>
          </div>

          {/* LOGIN BUTTON */}
          <button type="submit" className="btn-primary big login-btn">
            Login
          </button>
        </form>

        <p className="signup-text">
          Don’t have an account? <a href="/register">Register</a>
        </p>
      </div>
    </div>
  );
}
