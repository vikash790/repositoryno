// // import { useState, useEffect } from "react";
// // import { useNavigate } from "react-router-dom";
// // import "./Auth.css";

// // export default function SecurityQuestion() {
// //   const navigate = useNavigate();

// //   const securityQuestions = [
// //     {
// //       id: 1,
// //       question: "What is the name of your first school?",
// //       answer: "green valley"
// //     },
// //     {
// //       id: 2,
// //       question: "What is your mother's maiden name?",
// //       answer: "sharma"
// //     },
// //     {
// //       id: 3,
// //       question: "What city were you born in?",
// //       answer: "patna"
// //     },
// //     {
// //       id: 4,
// //       question: "What was the name of your first pet?",
// //       answer: "rocky"
// //     }
// //   ];

// //   const [selectedQuestion, setSelectedQuestion] = useState(null);
// //   const [userAnswer, setUserAnswer] = useState("");
// //   const [error, setError] = useState("");

// //   // Pick random question on load
// //   useEffect(() => {
// //     const random =
// //       securityQuestions[Math.floor(Math.random() * securityQuestions.length)];
// //     setSelectedQuestion(random);
// //   }, []);

// //   const handleSubmit = (e) => {
// //     e.preventDefault();

// //     if (
// //       userAnswer.trim().toLowerCase() !==
// //       selectedQuestion.answer.toLowerCase()
// //     ) {
// //       setError("Incorrect answer. Please try again.");
// //       setUserAnswer("");
// //       return;
// //     }

// //     setError("");
// //     navigate("/account"); // ✅ Final access
// //   };

// //   if (!selectedQuestion) return null;

// //   return (
// //     <div className="login-wrapper">
// //       <div className="login-card">
// //         <h2>Security Verification</h2>
// //         <p className="login-sub">
// //           Please answer the security question to continue
// //         </p>

// //         <form onSubmit={handleSubmit} className="login-form">

// //           <div className="security-question">
// //             {selectedQuestion.question}
// //           </div>

// //           <div className="input-group">
// //             <label>Your Answer</label>
// //             <input
// //               type="text"
// //               placeholder="Enter your answer"
// //               value={userAnswer}
// //               onChange={(e) => setUserAnswer(e.target.value)}
// //               required
// //             />
// //           </div>

// //           {error && <p className="error-text">{error}</p>}

// //           <button type="submit" className="btn-primary big login-btn">
// //             Verify & Continue
// //           </button>
// //         </form>
// //       </div>
// //     </div>
// //   );
// // }



// import { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import "./Auth.css";

// export default function SecurityQuestion() {
//   const navigate = useNavigate();

//   const securityQuestions = [
//     {
//       id: 1,
//       question: "What is the name of your first school?"
//     },
//     {
//       id: 2,
//       question: "What is your mother's maiden name?"
//     },
//     {
//       id: 3,
//       question: "What city were you born in?"
//     },
//     {
//       id: 4,
//       question: "What was the name of your first pet?"
//     }
//   ];

//   const [selectedQuestion, setSelectedQuestion] = useState(null);
//   const [userAnswer, setUserAnswer] = useState("");

//   // Pick random question on load
//   useEffect(() => {
//     const random =
//       securityQuestions[Math.floor(Math.random() * securityQuestions.length)];
//     setSelectedQuestion(random);
//   }, []);

//   const handleSubmit = (e) => {
//     e.preventDefault();

//     // ✅ Accept ANY answer
//     navigate("/account");
//   };

//   if (!selectedQuestion) return null;

//   return (
//     <div className="login-wrapper">
//       <div className="login-card">
//         <h2>Security Verification</h2>
//         <p className="login-sub">
//           Please answer the security question to continue
//         </p>

//         <form onSubmit={handleSubmit} className="login-form">

//           <div className="security-question">
//             {selectedQuestion.question}
//           </div>

//           <div className="input-group">
//             <label>Your Answer</label>
//             <input
//               type="text"
//               placeholder="Enter your answer"
//               value={userAnswer}
//               onChange={(e) => setUserAnswer(e.target.value)}
//               required
//             />
//           </div>

//           <button type="submit" className="btn-primary big login-btn">
//             Verify & Continue
//           </button>
//         </form>
//       </div>
//     </div>
//   );
// }


import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Auth.css";

export default function SecurityQuestion() {
  const navigate = useNavigate();

  const securityQuestions = [
    {
      id: 1,
      question: "What is the name of your first school?"
    },
    {
      id: 2,
      question: "What is your mother's maiden name?"
    },
    {
      id: 3,
      question: "What city were you born in?"
    },
    {
      id: 4,
      question: "What was the name of your first pet?"
    }
  ];

  const [selectedQuestion, setSelectedQuestion] = useState(null);
  const [userAnswer, setUserAnswer] = useState("");

  // Pick random question on load
  useEffect(() => {
    const random =
      securityQuestions[Math.floor(Math.random() * securityQuestions.length)];
    setSelectedQuestion(random);
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();

    // ✅ Accept ANY answer and go to OTP
    navigate("/otp");
  };

  if (!selectedQuestion) return null;

  return (
    <div className="login-wrapper">
      <div className="login-card">
        <h2>Security Verification</h2>
        <p className="login-sub">
          Please answer the security question to continue
        </p>

        <form onSubmit={handleSubmit} className="login-form">

          <div className="security-question">
            {selectedQuestion.question}
          </div>

          <div className="input-group">
            <label>Your Answer</label>
            <input
              type="text"
              placeholder="Enter your answer"
              value={userAnswer}
              onChange={(e) => setUserAnswer(e.target.value)}
              required
            />
          </div>

          <button type="submit" className="btn-primary big login-btn">
            Verify & Continue
          </button>
        </form>
      </div>
    </div>
  );
}
