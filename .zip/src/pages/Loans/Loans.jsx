export default function Loans() {
  return <h1 style={{ padding: "40px" }}>Loan Information Page</h1>;
}
