// import { Outlet } from "react-router-dom";

// export default function PublicRoutes() {
//   return <Outlet />;
// }


import { Outlet } from "react-router-dom";

export default function PublicRoutes() {
  return <Outlet />;
}
