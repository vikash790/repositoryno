// import { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import "./Auth.css";

// export default function CaptchaVerify() {
//   const navigate = useNavigate();

//   const [captchaText, setCaptchaText] = useState("");
//   const [userInput, setUserInput] = useState("");
//   const [error, setError] = useState("");

//   // Generate captcha when page loads
//   useEffect(() => {
//     generateCaptcha();
//   }, []);

//   const generateCaptcha = () => {
//     const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
//     let captcha = "";

//     for (let i = 0; i < 6; i++) {
//       captcha += chars.charAt(Math.floor(Math.random() * chars.length));
//     }

//     setCaptchaText(captcha);
//     setUserInput("");
//     setError("");
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();

//     if (userInput.trim().toUpperCase() !== captchaText) {
//       setError("Captcha does not match. Please try again.");
//       generateCaptcha();
//       return;
//     }

//     setError("");
//     navigate("/otp"); // ✅ Navigate to OTP
//   };

//   return (
//     <div className="login-wrapper">
//       <div className="login-card">
//         <h2>Captcha Verification</h2>
//         <p className="login-sub">
//           Please verify that you are not a robot
//         </p>

//         <form onSubmit={handleSubmit} className="login-form">

//           {/* CAPTCHA DISPLAY */}
//           <div className="captcha-box">
//             <span className="captcha-text">{captchaText}</span>
//             <button
//               type="button"
//               className="captcha-refresh"
//               onClick={generateCaptcha}
//               title="Refresh Captcha"
//             >
//               ↻
//             </button>
//           </div>

//           {/* CAPTCHA INPUT */}
//           <div className="input-group">
//             <label>Enter Captcha</label>
//             <input
//               type="text"
//               placeholder="Enter the characters shown above"
//               value={userInput}
//               onChange={(e) => setUserInput(e.target.value)}
//               required
//             />
//           </div>

//           {error && <p className="error-text">{error}</p>}

//           <button type="submit" className="btn-primary big login-btn">
//             Verify & Continue
//           </button>
//         </form>
//       </div>
//     </div>
//   );
// }


import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Auth.css";

export default function CaptchaVerify() {
  const navigate = useNavigate();

  const [captchaText, setCaptchaText] = useState("");
  const [userInput, setUserInput] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    generateCaptcha();
  }, []);

  const generateCaptcha = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let captcha = "";

    for (let i = 0; i < 6; i++) {
      captcha += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    setCaptchaText(captcha);
    setUserInput("");
    setError("");
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (userInput.trim().toUpperCase() !== captchaText) {
      setError("Captcha does not match. Please try again.");
      generateCaptcha();
      return;
    }

    setError("");
    navigate("/security-question"); // ✅ Navigate to Security Question
  };

  return (
    <div className="login-wrapper">
      <div className="login-card">
        <h2>Captcha Verification</h2>
        <p className="login-sub">
          Please verify that you are not a robot
        </p>

        <form onSubmit={handleSubmit} className="login-form">

          <div className="captcha-box">
            <span className="captcha-text">{captchaText}</span>
            <button
              type="button"
              className="captcha-refresh"
              onClick={generateCaptcha}
              title="Refresh Captcha"
            >
              ↻
            </button>
          </div>

          <div className="input-group">
            <label>Enter Captcha</label>
            <input
              type="text"
              placeholder="Enter the characters shown above"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              required
            />
          </div>

          {error && <p className="error-text">{error}</p>}

          <button type="submit" className="btn-primary big login-btn">
            Verify & Continue
          </button>
        </form>
      </div>
    </div>
  );
}
